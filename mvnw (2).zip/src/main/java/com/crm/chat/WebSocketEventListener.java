package com.crm.chat;

import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;
import com.crm.importLead.NotificationRemider;

@Component
public class WebSocketEventListener {

    private final NotificationRemider reminderService;

    public WebSocketEventListener(NotificationRemider reminderService) {
        this.reminderService = reminderService;
    }

    @EventListener
    public void handleSessionConnected(SessionConnectEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        String userIdStr = accessor.getFirstNativeHeader("userId"); // Send userId in headers from frontend
        if (userIdStr != null) {
            long userId = Long.parseLong(userIdStr);
            reminderService.startReminderForUser(userId);
        }
    }

    @EventListener
    public void handleSessionDisconnect(SessionDisconnectEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        String userIdStr = accessor.getFirstNativeHeader("userId");
        if (userIdStr != null) {
            long userId = Long.parseLong(userIdStr);
            reminderService.stopReminderForUser(userId);
        }
    }
}
